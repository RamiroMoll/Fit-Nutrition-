# Coach App (Expo + Supabase) — MVP

This is a super-simple starter for your coaching app: log **nutrition, protein, sleep, weight**, and **workouts**.
It uses **Expo (React Native)** and **Supabase** (Auth + Postgres + Row Level Security).

## Quickstart

1) Install Node 18+ and yarn or npm.
2) Create a new Supabase project → get your `SUPABASE_URL` and `ANON_KEY`.
3) In Supabase SQL editor, run the SQL from `supabase/schema.sql`.
4) Clone this folder or unzip the provided archive.
5) Copy `.env.example` to `.env` and fill in your keys.
6) Install deps:
   ```bash
   npm install
   ```
7) Run the app:
   ```bash
   npx expo start
   ```
   Use Expo Go on iOS/Android or an emulator.

## Files
- `app/today.tsx` — daily log (calories, protein, sleep, weight, notes).
- `app/new-workout.tsx` — create a workout and later add exercises.
- `lib/supabase.ts` — Supabase client config.
- `supabase/schema.sql` — DB tables + RLS policies.

## ENV
Create `.env`:
```
EXPO_PUBLIC_SUPABASE_URL=your-url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

## Notes
- This starter uses Expo Router for simple screen navigation.
- Authentication is left minimal (you can add Magic Link or email+password later).
- RLS policies restrict access so each coach only sees their own clients/data.
