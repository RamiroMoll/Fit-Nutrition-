-- Database schema and RLS policies

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  coach_id uuid not null references auth.users (id) on delete cascade,
  name text not null,
  email text unique,
  notes text,
  created_at timestamptz default now()
);

create table if not exists public.daily_logs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients (id) on delete cascade,
  date date not null,
  calories int,
  protein_g int,
  sleep_hours numeric(4,1),
  weight_kg numeric(5,2),
  notes text,
  created_at timestamptz default now(),
  unique (client_id, date)
);

create table if not exists public.workouts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients (id) on delete cascade,
  date date not null,
  title text not null,
  type text check (type in ('boksen','kracht','cardio','overig')),
  notes text,
  created_at timestamptz default now()
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  workout_id uuid not null references public.workouts (id) on delete cascade,
  name text not null,
  sets int,
  reps int,
  weight_kg numeric(6,2)
);

alter table public.clients enable row level security;
alter table public.daily_logs enable row level security;
alter table public.workouts enable row level security;
alter table public.exercises enable row level security;

create policy if not exists "coach_owns_clients"
on public.clients for all
using (auth.uid() = coach_id)
with check (auth.uid() = coach_id);

create policy if not exists "coach_reads_client_data"
on public.daily_logs for select using (
  exists (select 1 from public.clients c where c.id = daily_logs.client_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_writes_client_data"
on public.daily_logs for insert with check (
  exists (select 1 from public.clients c where c.id = client_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_updates_client_data"
on public.daily_logs for update using (
  exists (select 1 from public.clients c where c.id = client_id and c.coach_id = auth.uid())
);

create policy if not exists "coach_reads_workouts"
on public.workouts for select using (
  exists (select 1 from public.clients c where c.id = client_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_writes_workouts"
on public.workouts for insert with check (
  exists (select 1 from public.clients c where c.id = client_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_updates_workouts"
on public.workouts for update using (
  exists (select 1 from public.clients c where c.id = client_id and c.coach_id = auth.uid())
);

create policy if not exists "coach_reads_exercises"
on public.exercises for select using (
  exists (select 1 from public.workouts w join public.clients c on c.id = w.client_id
          where w.id = exercises.workout_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_writes_exercises"
on public.exercises for insert with check (
  exists (select 1 from public.workouts w join public.clients c on c.id = w.client_id
          where w.id = workout_id and c.coach_id = auth.uid())
);
create policy if not exists "coach_updates_exercises"
on public.exercises for update using (
  exists (select 1 from public.workouts w join public.clients c on c.id = w.client_id
          where w.id = workout_id and c.coach_id = auth.uid())
);
