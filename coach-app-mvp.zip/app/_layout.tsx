import { Stack } from "expo-router";

export default function RootLayout() {
  return (
    <Stack screenOptions={{ headerTitle: 'Coach App' }}>
      <Stack.Screen name="index" options={{ title: 'Home' }} />
      <Stack.Screen name="today" options={{ title: 'Vandaag' }} />
      <Stack.Screen name="new-workout" options={{ title: 'Nieuwe workout' }} />
    </Stack>
  );
}
