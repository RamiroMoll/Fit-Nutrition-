import { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { supabase } from '../lib/supabase';

export default function NewWorkout() {
  const [clientId, setClientId] = useState<string>('');
  const [date] = useState<string>(new Date().toISOString().slice(0,10));
  const [title, setTitle] = useState('Krachttraining');
  const [type, setType] = useState<'boksen'|'kracht'|'cardio'|'overig'>('kracht');

  const createWorkout = async () => {
    if (!clientId) return Alert.alert('Vul een client ID in.');
    const { data, error } = await supabase
      .from('workouts')
      .insert({ client_id: clientId, date, title, type })
      .select('id')
      .single();
    if (error) return Alert.alert('Fout', error.message);
    Alert.alert('Workout aangemaakt', `ID: ${data.id}`);
  };

  return (
    <View style={{ padding: 16, gap: 8 }}>
      <Text style={{ fontSize: 20, fontWeight: '600' }}>Nieuwe workout</Text>
      <TextInput placeholder="Client ID (tijdelijk)" value={clientId} onChangeText={setClientId} />
      <TextInput placeholder="Titel" value={title} onChangeText={setTitle} />
      <TextInput placeholder="Type (boksen/kracht/cardio/overig)" value={type} onChangeText={(t)=>setType(t as any)} />
      <Button title="Aanmaken" onPress={createWorkout} />
    </View>
  );
}
