import { Link } from "expo-router";
import { View, Text } from "react-native";

export default function Home() {
  return (
    <View style={{ flex: 1, padding: 16, gap: 12, justifyContent: 'center' }}>
      <Text style={{ fontSize: 22, fontWeight: '700' }}>Welkom 👋</Text>
      <Link href="/today" style={{ fontSize: 18 }}>📅 Vandaag loggen</Link>
      <Link href="/new-workout" style={{ fontSize: 18 }}>🏋️ Nieuwe workout</Link>
    </View>
  );
}
