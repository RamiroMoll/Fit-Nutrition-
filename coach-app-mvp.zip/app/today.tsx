import { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { supabase } from '../lib/supabase';

export default function TodayScreen() {
  const [clientId, setClientId] = useState<string>(''); // set once for now
  const [date] = useState<string>(new Date().toISOString().slice(0,10));
  const [calories, setCalories] = useState<string>('');
  const [protein, setProtein] = useState<string>('');
  const [sleep, setSleep] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    (async () => {
      if (!clientId) return;
      const { data, error } = await supabase
        .from('daily_logs')
        .select('*')
        .eq('client_id', clientId)
        .eq('date', date)
        .maybeSingle();
      if (!error && data) {
        setCalories(String(data.calories ?? ''));
        setProtein(String(data.protein_g ?? ''));
        setSleep(String(data.sleep_hours ?? ''));
        setWeight(String(data.weight_kg ?? ''));
        setNotes(data.notes ?? '');
      }
    })();
  }, [clientId, date]);

  const save = async () => {
    if (!clientId) return Alert.alert('Kies eerst een cliënt-id (tijdelijk veld).');
    const payload = {
      client_id: clientId,
      date,
      calories: calories ? Number(calories) : null,
      protein_g: protein ? Number(protein) : null,
      sleep_hours: sleep ? Number(sleep) : null,
      weight_kg: weight ? Number(weight) : null,
      notes: notes || null,
    };
    const { error } = await supabase
      .from('daily_logs')
      .upsert(payload, { onConflict: 'client_id,date' });
    if (error) Alert.alert('Fout', error.message);
    else Alert.alert('Opgeslagen', 'Daglog is bijgewerkt.');
  };

  return (
    <View style={{ padding: 16, gap: 8 }}>
      <Text style={{ fontSize: 20, fontWeight: '600' }}>Vandaag ({date})</Text>
      <TextInput placeholder="Client ID (tijdelijk)" value={clientId} onChangeText={setClientId} />
      <TextInput placeholder="Calorieën" keyboardType="number-pad" value={calories} onChangeText={setCalories} />
      <TextInput placeholder="Eiwit (g)" keyboardType="number-pad" value={protein} onChangeText={setProtein} />
      <TextInput placeholder="Slaap (uren)" keyboardType="decimal-pad" value={sleep} onChangeText={setSleep} />
      <TextInput placeholder="Gewicht (kg)" keyboardType="decimal-pad" value={weight} onChangeText={setWeight} />
      <TextInput placeholder="Notities" value={notes} onChangeText={setNotes} />
      <Button title="Opslaan" onPress={save} />
    </View>
  );
}
